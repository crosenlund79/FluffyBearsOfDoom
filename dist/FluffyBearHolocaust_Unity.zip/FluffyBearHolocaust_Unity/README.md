# Fluffy Bears of Doom: Unity port

A standalone Unity/C# port of the Godot 4.3 game. Gameplay, physics, AI, maps, power-ups,
curses, the Doom Duck Parade, taunts, Normal/Horror/Custom modes, menus, HUD, settings, music and
sound effects are all reimplemented natively in C#. The project needs nothing from the
original Godot project.

## Requirements
- **Unity 2022.3 LTS** (made for 2022.3.50f1; any 2022.3.x should work). It uses the Built-in
  Render Pipeline and only Unity's built-in modules, so no package downloads are needed.
- Target: Windows / macOS / Linux standalone.

## Open & play
1. Unity Hub → **Add** → select this folder (the one containing `Assets`, `Packages`, `ProjectSettings`).
2. Open `Assets/Scenes/Main.unity` and press **Play**.
   Everything is created at runtime by `App.cs` (`[RuntimeInitializeOnLoadMethod]`), so the
   scene only holds a camera.
3. To build: **File → Build Settings → Build** (the scene list is already set).

## Controls
| | Player 1 | Player 2 |
|---|---|---|
| Move | WASD | Arrow keys |
| Place bomb | Space | Enter |
| Steal fluff (hold) | Left Shift | Right Ctrl |
| Special (remote detonate / Line Bomb) | E | Right Shift |

A lone player can use either layout. Gamepad (XInput axis layout on Windows): left stick or d-pad,
A bomb, X/B/RT steal, Y/LB special, Start pause. In two-player mode pad 1 drives Player 1 and pad
2 drives Player 2. Esc/P pauses, N skips to the next music track. Menus work with the mouse,
arrows/WASD + Enter/Space, or the d-pad + A.

## Gameplay notes
- The roster: **Player** is a teddy bear, **Oswald** a teddy bunny, **Harald** a small dino and
  **Theodor** a teddy bear princess (Player 2 takes the character of whichever AI sits out). Each
  has its own Normal and Horror sprite sheet, shown in-game, in the menu line-up, HUD portraits and results.
- **Crane chair delivery:** rarely (first after 40–65 s, then every 60–90 s) a crane hook swings in
  with an armchair, hovers over a free cell with a drop marker and lets go. The chair holds 60 fluff:
  stand next to it and hold Steal to loot it. A blast bursts it open into pickups. The AI goes for it too.
  Tuning: `CRANE_*` / `CHAIR_FLUFF` in `Core/Tuning.cs`.
- Power-ups glow, bob and sparkle (curses bubble and twitch), and picking one up gives a shockwave,
  a pop and a floating label. Horror mode has its own badge sheet.
- Every bear can **kick** bombs by walking into one. A kicked bomb slides along the corridor until something blocks it.
  A ring in the owner's colour on the floor shows whose bomb it is.
- **Remote Detonator** power-up: your bombs wait, shown with an antenna in your colour, until you press the special key.
  A backup fuse sets them off after 10 s. Without remote bombs out, the special key lays a Line Bomb.
- Power-ups lying in a blast are destroyed; ones uncovered by that same blast survive.
- Ice is slippery but controllable. Even overstuffed bears keep a minimum braking force there.
- A gentle corridor assist helps bears turn into side corridors, including when the turn is pressed a little early.
- Horror mode: bears with blood on their feet leave fading footprints.
- Menu → **Settings**: volumes, mute, shuffle and **Bear outlines** (a dark outline for visibility).
  A "Now playing" note appears briefly whenever a track starts.

## Replacing art and audio (works in built games too)
All art and audio live in `Assets/StreamingAssets` and are loaded at runtime.

**Sprites** (`StreamingAssets/Sprites/<folder>/`): each sprite uses the first file that exists:
1. `<folder>/<mode>/<name>.png`: your mode-specific art (`mode` = `normal` or `horror`)
2. `<folder>/<name>.png`: your shared art
3. `<folder>/<mode>/template_<name>.png`: the built-in mode placeholder
4. `<folder>/template_<name>.png`: the built-in placeholder

**Custom mode** (the third button next to Normal and Horror) first looks for your art in
`<folder>/custom/<name>.png`, using the same file names as the templates, and otherwise shows
exactly what Normal shows. Custom files are never read in Normal or Horror. Custom plays and sounds
like Normal (menus, music, taunts); only the sprites change. The choice is saved like the other settings.

Your files always win and placeholders never overwrite anything. Sheets are a single row and the
cell size is `image width / cell count`.

| File | Cells |
|---|---|
| `bears/template_bear.png` | 10: body, belly, head, ear, arm, leg, face normal/smug/indignant/stunned |
| `bears/template_bunny.png`, `template_dino.png`, `template_princess.png` | 12: the same 10 as the bear, then tail (bunny puff / dino tail; the princess's skirt) and head topper (bow / back crest / crown). A missing character sheet falls back to the bear sheet |
| `objects/template_chair.png` | 1: the crane-delivered armchair (stuffing tufts are drawn on top in code) |
| `tiles/template_tiles.png` | 9: rug, rug alt, ice, honey, bouncy, conveyor (→), pillar, cushion block, border |
| `objects/template_bomb.png` | 1 (tinted per bear) |
| `objects/template_fluff.png` | 1 |
| `objects/template_duck.png` | 2: wind-up duck (→), wind-up key |
| `powerups/template_powerups.png` | 10: bomb, blast, speed, shuffle, kick, line, rubber, immortality, reverse, diarrhea (the Remote Detonator reuses the bomb cell with a drawn antenna). Halo, outline, sparkles and pickup burst are drawn in code |
| `effects/template_effects.png` | 8: blast centre, arm, end (→), star, dust, sparkle, bird (→), floor splat |

Horror placeholders exist for `bears` (all four characters), `tiles`, `effects`, `powerups` and `objects/chair`.

**Music** (`StreamingAssets/Audio/music/<menu|gameplay>/<normal|horror>/`): `.mp3`, `.ogg` and `.wav`
files are found automatically. Loose files in `menu/` or `gameplay/` are shared by both modes. If
a Horror folder is empty, the Normal tracks play slowed. In a built game you can also add tracks
to `music/<menu|gameplay>/<normal|horror>/` next to the executable, or under
`Application.persistentDataPath/music/`.

**Sound effects** (`StreamingAssets/Audio/sfx/`, Horror-only overrides in `sfx/horror/`): name a file
after the sound (`place fuse confetti concussion steal pickup curse squeak bump kick boing pop menu
tick go shuffle immortal victory taunt mode portal clock_tick quack duckling_quack duck_warning
duck_confetti crane chair_thud`) to replace the built-in procedural placeholder.

Settings (volumes, mute, shuffle, mode, players, AI levels, arena, round length) are saved to
`Application.persistentDataPath/settings.json`.

## Code map (`Assets/Scripts`)
- `Core/`: `Tuning` (every gameplay number), `Terrain`, `ArenaMaps`, `Settings`, `ModeTheme` (+ `Taunts`), `Assets` (sprite loader), `Controls` (input), `Gd` (math helpers).
- `Game/`: `Game` (match logic), `Arena`, `Bear` (physics, theft, curses, taunts), `BearVisual` (procedural plush rig), `AiController`, `HumanController`, `Bomb`, `DuckParade`, `Chair` (crane event + delivered chair), `Effects` (blasts, particles, pickups, power-ups, pickup FX, decals). `Core/Species` holds the character roster.
- `Render/`: `Painter` (batched 2D drawing in 1280×720 canvas space), `Xf` (2D transforms).
- `UI/`: `Menu`, `Hud`, `AudioPanel` (the Settings panel), `NowPlaying`, `Gui` (widgets), `UiStyle` (palettes).
- `Audio/`: `Sfx` (procedural placeholders + replacements), `Music` (playlists, fades), `AudioHub`.
- `App.cs`: bootstrap, camera, scene flow.

## Implementation notes
- **Drawing:** the game draws everything procedurally each frame, as the original did with
  Godot `_draw()`. Gameplay objects are plain C# classes updated by `App`, so there are no
  prefabs. Physics runs in `FixedUpdate` at 60 Hz, the same tick rate as Godot.
- **Text:** text uses an OS serif font (Georgia, Palatino, DejaVu Serif, …) through Unity's
  dynamic fonts, falling back to Unity's built-in font.
- **Audio volumes:** Master, Music and SFX are applied as gains, because Godot's audio buses have
  no Unity equivalent without a mixer asset.
- **Gamepad axis numbers:** these follow the Windows XInput layout. macOS and Linux drivers
  number axes and buttons differently, so d-pad and trigger mappings may need adjusting in
  `ProjectSettings/InputManager.asset` there.
- **Known quirk kept from the original:** when a second Biome Shuffle starts while an earlier one
  is still active, the earlier shuffle's cells show warning outlines again until they revert.
